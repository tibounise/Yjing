<?php

	$datafile_url = "data.xml";
	$yjing_version_string = "1.1";
	$yjing_version_int = 1.1;
	$login = array(0 => "<username>", 1 => "<password>");
	
?>